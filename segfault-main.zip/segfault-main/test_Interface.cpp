#include"Interface.h"

int main(){
    Program p1;
    p1.welcome();
}